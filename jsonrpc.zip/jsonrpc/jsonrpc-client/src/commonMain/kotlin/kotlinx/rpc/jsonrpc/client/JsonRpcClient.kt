/*
 * Copyright 2023-2025 JetBrains s.r.o and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package kotlinx.rpc.jsonrpc.client

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.Flow
import kotlinx.rpc.jsonrpc.*
import kotlinx.rpc.jsonrpc.internal.ConcurrentMap
import kotlinx.rpc.jsonrpc.internal.concurrentMapOf
import kotlinx.serialization.KSerializer
import kotlinx.serialization.json.*
import kotlinx.serialization.serializer
import kotlinx.atomicfu.atomic
import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds

/**
 * Configuration for JSON-RPC client.
 */
public data class JsonRpcClientConfig(
    val requestTimeout: Duration = 30.seconds,
    val idGenerator: RpcIdGenerator = RpcIdGenerator.Sequential(),
    val sendCancelNotification: Boolean = true
)

/**
 * JSON-RPC 2.0 Client.
 */
public class JsonRpcClient(
    public val transport: JsonRpcTransport,
    private val scope: CoroutineScope,
    public val config: JsonRpcClientConfig = JsonRpcClientConfig()
) : AutoCloseable {
    
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = false }
    private val idGenerator = config.idGenerator
    private val pendingRequests: ConcurrentMap<RpcId, CompletableDeferred<JsonRpcResponse>> = concurrentMapOf()
    
    private val _closed = atomic(false)
    private var closed: Boolean
        get() = _closed.value
        set(value) { _closed.value = value }

    init {
        scope.launch {
            transport.receive().collect { message ->
                handleIncomingMessage(message)
            }
        }
    }

    /**
     * Makes a JSON-RPC call with serializer.
     */
    public suspend fun <T> call(
        method: String,
        params: JsonElement?,
        resultDeserializer: KSerializer<T>
    ): T {
        checkNotClosed()
        
        val requestId = idGenerator.nextId()
        val request = JsonRpcRequest.request(requestId, method, params)
        val response = sendRequest(request)
        
        if (response.isError) {
            throw response.error!!.toException()
        }
        
        return json.decodeFromJsonElement(resultDeserializer, response.result!!)
    }

    /**
     * Sends a notification (no response expected).
     */
    public suspend fun notify(method: String, params: JsonElement? = null) {
        checkNotClosed()
        val request = JsonRpcRequest.notification(method, params)
        val requestJson = json.encodeToString(JsonRpcRequest.serializer(), request)
        transport.send(requestJson)
    }

    /**
     * Sends a raw JSON-RPC request.
     */
    public suspend fun sendRaw(request: String): String? {
        checkNotClosed()
        return transport.send(request)
    }

    /**
     * Cancels a pending request.
     */
    public suspend fun cancel(requestId: RpcId) {
        val paramsObj = buildJsonObject {
            when (requestId) {
                is RpcId.StringId -> put("id", requestId.value)
                is RpcId.NumberId -> put("id", requestId.value)
                is RpcId.Null -> { }
            }
        }
        notify("$/cancelRequest", paramsObj)
        pendingRequests.remove(requestId)?.cancel()
    }

    /**
     * Returns incoming messages flow.
     */
    public fun incoming(): Flow<String> = transport.receive()

    override fun close() {
        if (closed) return
        closed = true
        pendingRequests.forEach { _, deferred -> deferred.cancel() }
        pendingRequests.clear()
        transport.close()
    }

    private suspend fun sendRequest(request: JsonRpcRequest): JsonRpcResponse {
        val requestJson = json.encodeToString(JsonRpcRequest.serializer(), request)
        
        val responseJson = withTimeout(config.requestTimeout) {
            transport.send(requestJson)
        }
        
        if (responseJson == null) {
            val deferred = CompletableDeferred<JsonRpcResponse>()
            val id = request.id ?: throw IllegalStateException("Request must have an id")
            pendingRequests[id] = deferred
            
            return try {
                withTimeout(config.requestTimeout) { deferred.await() }
            } finally {
                pendingRequests.remove(id)
            }
        }
        
        return json.decodeFromString(JsonRpcResponse.serializer(), responseJson)
    }

    private fun handleIncomingMessage(message: String) {
        try {
            val response = json.decodeFromString(JsonRpcResponse.serializer(), message)
            val id = response.id ?: return
            pendingRequests.remove(id)?.complete(response)
        } catch (_: Exception) { }
    }

    private fun checkNotClosed() {
        if (closed) throw IllegalStateException("Client is closed")
    }
}

/**
 * Extension for typed calls.
 */
public suspend inline fun <reified T> JsonRpcClient.call(
    method: String,
    params: JsonElement? = null
): T = call(method, params, serializer())
