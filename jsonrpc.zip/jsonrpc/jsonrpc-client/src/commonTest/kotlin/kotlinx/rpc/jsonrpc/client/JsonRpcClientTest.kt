/*
 * Copyright 2023-2025 JetBrains s.r.o and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package kotlinx.rpc.jsonrpc.client

import kotlin.test.*

class JsonRpcClientConfigTest {
    @Test
    fun testDefaultConfig() {
        val config = JsonRpcClientConfig()
        assertEquals(30_000L, config.requestTimeout.inWholeMilliseconds)
        assertTrue(config.sendCancelNotification)
    }
}
