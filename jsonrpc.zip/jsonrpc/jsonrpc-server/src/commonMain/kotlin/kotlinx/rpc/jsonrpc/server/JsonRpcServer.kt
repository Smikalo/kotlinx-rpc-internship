/*
 * Copyright 2023-2025 JetBrains s.r.o and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package kotlinx.rpc.jsonrpc.server

import kotlinx.atomicfu.atomic
import kotlinx.coroutines.*
import kotlinx.rpc.jsonrpc.*
import kotlinx.rpc.jsonrpc.internal.ConcurrentMap
import kotlinx.rpc.jsonrpc.internal.concurrentMapOf
import kotlinx.serialization.json.*

/**
 * Configuration for JSON-RPC server.
 */
public data class JsonRpcServerConfig(
    val maxBatchSize: Int = 100,
    val maxRequestSize: Long = 1024 * 1024,
    val exposeInternalErrors: Boolean = false
)

/**
 * Handler type for JSON-RPC methods.
 */
public typealias MethodHandler = suspend (JsonElement?) -> JsonElement?

/**
 * JSON-RPC 2.0 Server.
 */
public class JsonRpcServer(
    public val config: JsonRpcServerConfig = JsonRpcServerConfig()
) : AutoCloseable {
    
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = false }
    private val methods: ConcurrentMap<String, MethodHandler> = concurrentMapOf()
    private val activeRequests: ConcurrentMap<RpcId, Job> = concurrentMapOf()
    
    private val _closed = atomic(false)
    private var closed: Boolean
        get() = _closed.value
        set(value) { _closed.value = value }

    /**
     * Registers a method handler.
     */
    public fun registerMethod(name: String, handler: MethodHandler) {
        methods[name] = handler
    }

    /**
     * Deregisters a method.
     */
    public fun deregisterMethod(name: String) {
        methods.remove(name)
    }

    /**
     * Lists all registered methods.
     */
    public fun listMethods(): List<String> = buildList {
        methods.forEach { name, _ -> add(name) }
    }

    /**
     * Handles a JSON-RPC request string.
     */
    public suspend fun handleRequest(requestJson: String): String? {
        if (closed) return null
        
        val element = try {
            json.parseToJsonElement(requestJson)
        } catch (e: Exception) {
            return json.encodeToString(JsonRpcResponse.serializer(), JsonRpcResponse.parseError())
        }
        
        return when (element) {
            is JsonArray -> handleBatch(element)
            is JsonObject -> handleSingleRequest(element)
            else -> json.encodeToString(JsonRpcResponse.serializer(), JsonRpcResponse.invalidRequest())
        }
    }

    /**
     * Cancels a request by ID.
     */
    public fun cancelRequest(id: RpcId): Boolean {
        val job = activeRequests.remove(id)
        job?.cancel()
        return job != null
    }

    /**
     * Returns active request IDs.
     */
    public fun activeRequests(): List<RpcId> = buildList {
        activeRequests.forEach { id, _ -> add(id) }
    }

    override fun close() {
        closed = true
        activeRequests.forEach { _, job -> job.cancel() }
        activeRequests.clear()
    }

    private suspend fun handleBatch(array: JsonArray): String {
        if (array.isEmpty()) {
            return json.encodeToString(JsonRpcResponse.serializer(), JsonRpcResponse.invalidRequest())
        }
        
        if (array.size > config.maxBatchSize) {
            return json.encodeToString(JsonRpcResponse.serializer(), 
                JsonRpcResponse.error(null, JsonRpcErrorObject(
                    code = JsonRpcErrorObject.BATCH_TOO_LARGE,
                    message = "Batch too large: ${array.size} (max: ${config.maxBatchSize})"
                ))
            )
        }
        
        val responses = array.mapNotNull { element ->
            if (element is JsonObject) {
                val responseJson = handleSingleRequest(element)
                responseJson?.let { json.parseToJsonElement(it) }
            } else null
        }
        
        return if (responses.isEmpty()) "null"
        else json.encodeToString(JsonArray(responses))
    }

    private suspend fun handleSingleRequest(obj: JsonObject): String? {
        val request = try {
            json.decodeFromJsonElement(JsonRpcRequest.serializer(), obj)
        } catch (e: Exception) {
            return json.encodeToString(JsonRpcResponse.serializer(), JsonRpcResponse.invalidRequest())
        }
        
        // Notifications don't get responses
        if (request.isNotification) {
            executeMethod(request)
            return null
        }
        
        val response = try {
            val result = executeMethod(request)
            JsonRpcResponse.success(request.id, result ?: JsonNull)
        } catch (e: JsonRpcException) {
            JsonRpcResponse.error(request.id, JsonRpcErrorObject(e.code, e.message ?: "Error"))
        } catch (e: Exception) {
            if (config.exposeInternalErrors) {
                JsonRpcResponse.internalError(request.id, e.message)
            } else {
                JsonRpcResponse.internalError(request.id)
            }
        }
        
        return json.encodeToString(JsonRpcResponse.serializer(), response)
    }

    private suspend fun executeMethod(request: JsonRpcRequest): JsonElement? {
        val handler = methods[request.method]
            ?: throw MethodNotFoundException(request.method)
        return handler(request.params)
    }
}
