/*
 * Copyright 2023-2025 JetBrains s.r.o and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package kotlinx.rpc.jsonrpc.server

import kotlinx.serialization.json.*
import kotlin.test.*

class JsonRpcServerTest {
    @Test
    fun testRegisterMethod() {
        val server = JsonRpcServer()
        server.registerMethod("test.add") { JsonPrimitive(42) }
        assertTrue(server.listMethods().contains("test.add"))
    }

    @Test
    fun testDeregisterMethod() {
        val server = JsonRpcServer()
        server.registerMethod("test.method") { JsonNull }
        server.deregisterMethod("test.method")
        assertFalse(server.listMethods().contains("test.method"))
    }

    @Test
    fun testDefaultConfig() {
        val config = JsonRpcServerConfig()
        assertEquals(100, config.maxBatchSize)
        assertFalse(config.exposeInternalErrors)
    }
}
