/*
 * Copyright 2023-2025 JetBrains s.r.o and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package kotlinx.rpc.jsonrpc

import kotlin.random.Random

internal actual fun generateUuid(): String {
    val chars = "0123456789abcdef"
    return buildString {
        repeat(8) { append(chars[Random.nextInt(16)]) }
        append('-')
        repeat(4) { append(chars[Random.nextInt(16)]) }
        append("-4")
        repeat(3) { append(chars[Random.nextInt(16)]) }
        append('-')
        append(chars[8 + Random.nextInt(4)])
        repeat(3) { append(chars[Random.nextInt(16)]) }
        append('-')
        repeat(12) { append(chars[Random.nextInt(16)]) }
    }
}
