/*
 * Copyright 2023-2025 JetBrains s.r.o and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package kotlinx.rpc.jsonrpc.internal

public actual class ConcurrentMap<K, V> actual constructor() {
    private val map = mutableMapOf<K, V>()

    public actual operator fun get(key: K): V? = map[key]
    public actual operator fun set(key: K, value: V): Unit { map[key] = value }
    public actual fun remove(key: K): V? = map.remove(key)
    public actual fun putIfAbsent(key: K, value: V): V? {
        val existing = map[key]
        if (existing == null) map[key] = value
        return existing
    }
    public actual fun clear(): Unit { map.clear() }
    public actual fun forEach(action: (K, V) -> Unit): Unit = map.forEach { (k, v) -> action(k, v) }
    public actual val size: Int get() = map.size
}

public actual fun <K, V> concurrentMapOf(): ConcurrentMap<K, V> = ConcurrentMap()
