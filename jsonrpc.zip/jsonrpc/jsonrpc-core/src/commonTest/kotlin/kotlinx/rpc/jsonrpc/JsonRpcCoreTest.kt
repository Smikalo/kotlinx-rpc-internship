/*
 * Copyright 2023-2025 JetBrains s.r.o and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package kotlinx.rpc.jsonrpc

import kotlinx.serialization.json.*
import kotlin.test.*

class RpcIdTest {
    @Test
    fun testStringId() {
        val id = RpcId.StringId("test")
        assertEquals("test", id.value)
    }

    @Test
    fun testNumberId() {
        val id = RpcId.NumberId(42)
        assertEquals(42L, id.value)
    }
}

class JsonRpcRequestTest {
    @Test
    fun testRequest() {
        val request = JsonRpcRequest.request(RpcId.NumberId(1), "test.method")
        assertEquals("test.method", request.method)
        assertEquals("2.0", request.jsonrpc)
        assertFalse(request.isNotification)
    }

    @Test
    fun testNotification() {
        val notification = JsonRpcRequest.notification("test.notify")
        assertTrue(notification.isNotification)
    }
}

class JsonRpcResponseTest {
    @Test
    fun testSuccess() {
        val response = JsonRpcResponse.success(RpcId.NumberId(1), JsonPrimitive("result"))
        assertTrue(response.isSuccess)
        assertFalse(response.isError)
    }

    @Test
    fun testError() {
        val response = JsonRpcResponse.parseError()
        assertTrue(response.isError)
        assertEquals(JsonRpcErrorObject.PARSE_ERROR, response.error!!.code)
    }
}

class RpcIdGeneratorTest {
    @Test
    fun testSequential() {
        val gen = RpcIdGenerator.Sequential()
        val id1 = gen.nextId() as RpcId.NumberId
        val id2 = gen.nextId() as RpcId.NumberId
        assertEquals(1L, id1.value)
        assertEquals(2L, id2.value)
    }
}
