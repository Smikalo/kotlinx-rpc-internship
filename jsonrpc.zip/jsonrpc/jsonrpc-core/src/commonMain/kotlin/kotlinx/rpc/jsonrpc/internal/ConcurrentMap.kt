/*
 * Copyright 2023-2025 JetBrains s.r.o and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package kotlinx.rpc.jsonrpc.internal

public expect class ConcurrentMap<K, V>() {
    public operator fun get(key: K): V?
    public operator fun set(key: K, value: V)
    public fun remove(key: K): V?
    public fun putIfAbsent(key: K, value: V): V?
    public fun clear(): Unit
    public fun forEach(action: (K, V) -> Unit): Unit
    public val size: Int
}

public expect fun <K, V> concurrentMapOf(): ConcurrentMap<K, V>
