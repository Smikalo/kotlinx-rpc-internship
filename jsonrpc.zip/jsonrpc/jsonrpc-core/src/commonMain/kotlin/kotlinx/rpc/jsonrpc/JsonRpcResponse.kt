/*
 * Copyright 2023-2025 JetBrains s.r.o and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package kotlinx.rpc.jsonrpc

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement

/**
 * Represents a JSON-RPC 2.0 Response object.
 */
@Serializable
public data class JsonRpcResponse(
    @SerialName("jsonrpc")
    val jsonrpc: String = "2.0",
    @SerialName("result")
    val result: JsonElement? = null,
    @SerialName("error")
    val error: JsonRpcErrorObject? = null,
    @SerialName("id")
    val id: RpcId?
) {
    public val isSuccess: Boolean get() = error == null && result != null
    public val isError: Boolean get() = error != null

    public fun getResultOrThrow(): JsonElement {
        if (error != null) throw error.toException()
        return result ?: throw IllegalStateException("Response has neither result nor error")
    }

    public companion object {
        public fun success(id: RpcId?, result: JsonElement): JsonRpcResponse =
            JsonRpcResponse(id = id, result = result)

        public fun error(id: RpcId?, error: JsonRpcErrorObject): JsonRpcResponse =
            JsonRpcResponse(id = id, error = error)

        public fun parseError(): JsonRpcResponse =
            JsonRpcResponse(id = null, error = JsonRpcErrorObject.parseError())

        public fun invalidRequest(id: RpcId? = null): JsonRpcResponse =
            JsonRpcResponse(id = id, error = JsonRpcErrorObject.invalidRequest())

        public fun methodNotFound(id: RpcId?, method: String? = null): JsonRpcResponse =
            JsonRpcResponse(id = id, error = JsonRpcErrorObject.methodNotFound(method))

        public fun invalidParams(id: RpcId?, details: String? = null): JsonRpcResponse =
            JsonRpcResponse(id = id, error = JsonRpcErrorObject.invalidParams(details))

        public fun internalError(id: RpcId?, details: String? = null): JsonRpcResponse =
            JsonRpcResponse(id = id, error = JsonRpcErrorObject.internalError(details))

        public fun timeout(id: RpcId?): JsonRpcResponse =
            JsonRpcResponse(id = id, error = JsonRpcErrorObject.timeout())

        public fun requestCancelled(id: RpcId?): JsonRpcResponse =
            JsonRpcResponse(id = id, error = JsonRpcErrorObject.requestCancelled(id))

        public fun serverBusy(id: RpcId?): JsonRpcResponse =
            JsonRpcResponse(id = id, error = JsonRpcErrorObject.serverBusy())

        public fun rateLimited(id: RpcId?): JsonRpcResponse =
            JsonRpcResponse(id = id, error = JsonRpcErrorObject.rateLimited())

        public fun connectionError(id: RpcId?): JsonRpcResponse =
            JsonRpcResponse(id = id, error = JsonRpcErrorObject.connectionError())
    }
}
