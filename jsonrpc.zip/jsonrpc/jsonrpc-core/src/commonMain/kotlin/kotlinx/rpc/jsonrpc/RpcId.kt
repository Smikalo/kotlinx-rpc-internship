/*
 * Copyright 2023-2025 JetBrains s.r.o and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package kotlinx.rpc.jsonrpc

import kotlinx.serialization.*
import kotlinx.serialization.descriptors.*
import kotlinx.serialization.encoding.*
import kotlinx.serialization.json.*

/**
 * Represents a JSON-RPC request/response identifier.
 */
@Serializable(with = RpcIdSerializer::class)
public sealed class RpcId {
    public data object Null : RpcId() {
        override fun toString(): String = "null"
    }

    public data class StringId(val value: String) : RpcId() {
        override fun toString(): String = value
    }

    public data class NumberId(val value: Long) : RpcId() {
        public constructor(value: Int) : this(value.toLong())
        override fun toString(): String = value.toString()
    }

    public companion object {
        public fun of(value: String): RpcId = StringId(value)
        public fun of(value: Long): RpcId = NumberId(value)
        public fun of(value: Int): RpcId = NumberId(value.toLong())
    }
}

/**
 * Serializer for RpcId.
 */
public object RpcIdSerializer : KSerializer<RpcId> {
    override val descriptor: SerialDescriptor = buildClassSerialDescriptor("RpcId")

    override fun serialize(encoder: Encoder, value: RpcId) {
        val jsonEncoder = encoder as? JsonEncoder
            ?: throw SerializationException("RpcId can only be serialized to JSON")
        val element = when (value) {
            is RpcId.Null -> JsonNull
            is RpcId.StringId -> JsonPrimitive(value.value)
            is RpcId.NumberId -> JsonPrimitive(value.value)
        }
        jsonEncoder.encodeJsonElement(element)
    }

    override fun deserialize(decoder: Decoder): RpcId {
        val jsonDecoder = decoder as? JsonDecoder
            ?: throw SerializationException("RpcId can only be deserialized from JSON")
        return when (val element = jsonDecoder.decodeJsonElement()) {
            is JsonNull -> RpcId.Null
            is JsonPrimitive -> when {
                element.isString -> RpcId.StringId(element.content)
                else -> element.longOrNull?.let { RpcId.NumberId(it) }
                    ?: throw SerializationException("Invalid RpcId: $element")
            }
            else -> throw SerializationException("Invalid RpcId type")
        }
    }
}
