/*
 * Copyright 2023-2025 JetBrains s.r.o and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package kotlinx.rpc.jsonrpc

import kotlin.time.Duration

/**
 * Base exception for JSON-RPC errors.
 */
public sealed class JsonRpcException(
    override val message: String,
    cause: Throwable? = null
) : Exception(message, cause) {
    public abstract val code: Int
    public open fun isRetriable(): Boolean = false
}

public class ParseErrorException(
    message: String = "Parse error"
) : JsonRpcException(message) {
    override val code: Int = JsonRpcErrorObject.PARSE_ERROR
}

public class InvalidRequestException(
    message: String = "Invalid Request"
) : JsonRpcException(message) {
    override val code: Int = JsonRpcErrorObject.INVALID_REQUEST
}

public class MethodNotFoundException(
    public val method: String? = null
) : JsonRpcException("Method not found" + (method?.let { ": $it" } ?: "")) {
    override val code: Int = JsonRpcErrorObject.METHOD_NOT_FOUND
}

public class InvalidParamsException(
    message: String = "Invalid params"
) : JsonRpcException(message) {
    override val code: Int = JsonRpcErrorObject.INVALID_PARAMS
}

public class InternalErrorException(
    message: String = "Internal error",
    cause: Throwable? = null
) : JsonRpcException(message, cause) {
    override val code: Int = JsonRpcErrorObject.INTERNAL_ERROR
}

public class JsonRpcTimeoutException : JsonRpcException {
    override val code: Int = JsonRpcErrorObject.TIMEOUT
    override fun isRetriable(): Boolean = true

    public constructor(message: String = "Request timeout", cause: Throwable? = null) : super(message, cause)
    
    public constructor(timeout: Duration, operation: String? = null) : super(
        buildString {
            append("Request timeout")
            operation?.let { append(" for $it") }
            append(" after ${timeout.inWholeMilliseconds}ms")
        }
    )
}

public class RequestCancelledException(
    message: String = "Request cancelled",
    cause: Throwable? = null,
    public val requestId: RpcId? = null
) : JsonRpcException(message, cause) {
    override val code: Int = JsonRpcErrorObject.REQUEST_CANCELLED
}

public class JsonRpcTransportException(
    message: String,
    cause: Throwable? = null
) : JsonRpcException(message, cause) {
    override val code: Int = JsonRpcErrorObject.INTERNAL_ERROR
    override fun isRetriable(): Boolean = true
}

public class ServerBusyException(
    message: String = "Server busy"
) : JsonRpcException(message) {
    override val code: Int = JsonRpcErrorObject.SERVER_BUSY
    override fun isRetriable(): Boolean = true
}

public class ServerErrorException(
    override val code: Int,
    message: String
) : JsonRpcException(message) {
    init {
        require(code in JsonRpcErrorObject.SERVER_ERROR_RANGE) {
            "Server error code must be in range ${JsonRpcErrorObject.SERVER_ERROR_RANGE}"
        }
    }
}

public class ConnectionErrorException(
    message: String = "Connection error",
    cause: Throwable? = null
) : JsonRpcException(message, cause) {
    override val code: Int = JsonRpcErrorObject.CONNECTION_ERROR
    override fun isRetriable(): Boolean = true
}

public class RateLimitedException(
    message: String = "Rate limited"
) : JsonRpcException(message) {
    override val code: Int = JsonRpcErrorObject.RATE_LIMITED
    override fun isRetriable(): Boolean = true
}
