/*
 * Copyright 2023-2025 JetBrains s.r.o and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package kotlinx.rpc.jsonrpc

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement

/**
 * Represents a JSON-RPC 2.0 Error object.
 */
@Serializable
public data class JsonRpcErrorObject(
    @SerialName("code")
    val code: Int,
    @SerialName("message")
    val message: String,
    @SerialName("data")
    val data: JsonElement? = null
) {
    public fun isReservedError(): Boolean = code in -32768..-32000
    public fun isServerError(): Boolean = code in SERVER_ERROR_RANGE
    public fun isRetriable(): Boolean = code in listOf(TIMEOUT, SERVER_BUSY, CONNECTION_ERROR, RATE_LIMITED)

    public fun toException(): JsonRpcException = when (code) {
        PARSE_ERROR -> ParseErrorException()
        INVALID_REQUEST -> InvalidRequestException(message)
        METHOD_NOT_FOUND -> MethodNotFoundException()
        INVALID_PARAMS -> InvalidParamsException(message)
        INTERNAL_ERROR -> InternalErrorException(message)
        REQUEST_CANCELLED -> RequestCancelledException(message)
        SERVER_BUSY -> ServerBusyException(message)
        TIMEOUT -> JsonRpcTimeoutException(message)
        CONNECTION_ERROR -> ConnectionErrorException(message)
        RATE_LIMITED -> RateLimitedException(message)
        in SERVER_ERROR_RANGE -> ServerErrorException(code, message)
        else -> InternalErrorException(message)
    }

    public companion object {
        public const val PARSE_ERROR: Int = -32700
        public const val INVALID_REQUEST: Int = -32600
        public const val METHOD_NOT_FOUND: Int = -32601
        public const val INVALID_PARAMS: Int = -32602
        public const val INTERNAL_ERROR: Int = -32603
        public const val REQUEST_CANCELLED: Int = -32000
        public const val SERVER_BUSY: Int = -32001
        public const val BATCH_TOO_LARGE: Int = -32002
        public const val REQUEST_TOO_LARGE: Int = -32003
        public const val TIMEOUT: Int = -32004
        public const val CONNECTION_ERROR: Int = -32005
        public const val RATE_LIMITED: Int = -32006

        public val SERVER_ERROR_RANGE: IntRange = -32099..-32000

        public fun parseError(): JsonRpcErrorObject = JsonRpcErrorObject(PARSE_ERROR, "Parse error")
        public fun invalidRequest(): JsonRpcErrorObject = JsonRpcErrorObject(INVALID_REQUEST, "Invalid Request")
        public fun methodNotFound(method: String? = null): JsonRpcErrorObject = 
            JsonRpcErrorObject(METHOD_NOT_FOUND, "Method not found" + (method?.let { ": $it" } ?: ""))
        public fun invalidParams(details: String? = null): JsonRpcErrorObject = 
            JsonRpcErrorObject(INVALID_PARAMS, details ?: "Invalid params")
        public fun internalError(details: String? = null): JsonRpcErrorObject = 
            JsonRpcErrorObject(INTERNAL_ERROR, details ?: "Internal error")
        public fun timeout(): JsonRpcErrorObject = JsonRpcErrorObject(TIMEOUT, "Request timeout")
        public fun requestCancelled(id: RpcId? = null): JsonRpcErrorObject = 
            JsonRpcErrorObject(REQUEST_CANCELLED, "Request cancelled" + (id?.let { ": $it" } ?: ""))
        public fun serverBusy(): JsonRpcErrorObject = JsonRpcErrorObject(SERVER_BUSY, "Server busy")
        public fun rateLimited(): JsonRpcErrorObject = JsonRpcErrorObject(RATE_LIMITED, "Rate limited")
        public fun connectionError(): JsonRpcErrorObject = JsonRpcErrorObject(CONNECTION_ERROR, "Connection error")
    }
}
