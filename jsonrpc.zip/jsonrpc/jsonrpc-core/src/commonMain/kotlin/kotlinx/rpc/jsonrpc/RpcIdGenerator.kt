/*
 * Copyright 2023-2025 JetBrains s.r.o and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package kotlinx.rpc.jsonrpc

import kotlinx.atomicfu.atomic

/**
 * Generator for JSON-RPC request IDs.
 */
public interface RpcIdGenerator {
    public fun nextId(): RpcId

    public class Sequential(start: Long = 1) : RpcIdGenerator {
        private val counter = atomic(start)
        override fun nextId(): RpcId = RpcId.NumberId(counter.getAndIncrement())
    }

    public class Uuid : RpcIdGenerator {
        override fun nextId(): RpcId = RpcId.StringId(generateUuid())
    }

    public class PrefixedSequential(
        private val prefix: String,
        start: Long = 1
    ) : RpcIdGenerator {
        private val counter = atomic(start)
        override fun nextId(): RpcId = RpcId.StringId("$prefix${counter.getAndIncrement()}")
    }

    public companion object {
        public fun sequential(start: Long = 1): RpcIdGenerator = Sequential(start)
        public fun uuid(): RpcIdGenerator = Uuid()
        public fun prefixed(prefix: String, start: Long = 1): RpcIdGenerator = PrefixedSequential(prefix, start)
    }
}

internal expect fun generateUuid(): String
