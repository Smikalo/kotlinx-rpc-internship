/*
 * Copyright 2023-2025 JetBrains s.r.o and contributors. Use of this source code is governed by the Apache 2.0 license.
 */

package kotlinx.rpc.jsonrpc

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject

/**
 * Represents a JSON-RPC 2.0 Request object.
 */
@Serializable
public data class JsonRpcRequest(
    @SerialName("jsonrpc")
    val jsonrpc: String = "2.0",
    @SerialName("method")
    val method: String,
    @SerialName("params")
    val params: JsonElement? = null,
    @SerialName("id")
    val id: RpcId? = null
) {
    public val isNotification: Boolean get() = id == null

    public companion object {
        public fun request(id: RpcId, method: String, params: JsonElement? = null): JsonRpcRequest =
            JsonRpcRequest(method = method, params = params, id = id)

        public fun notification(method: String, params: JsonElement? = null): JsonRpcRequest =
            JsonRpcRequest(method = method, params = params, id = null)

        public fun cancelNotification(requestId: RpcId): JsonRpcRequest =
            notification("$/cancelRequest", buildJsonObject {
                when (requestId) {
                    is RpcId.StringId -> put("id", JsonPrimitive(requestId.value))
                    is RpcId.NumberId -> put("id", JsonPrimitive(requestId.value))
                    is RpcId.Null -> { }
                }
            })
    }
}
